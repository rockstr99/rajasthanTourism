<?php
$hostname="localhost"; 
$username="root";
$password="";
$database="registration";
$conn=mysqli_connect($hostname,$username,$password,$database);
 
if(!$conn)
{
die("Connection cannot be establish: " . mysqli_connect_error());
}
 
$query="SELECT image FROM images WHERE id='1' ";
$query=mysql_query($conn,$query);
 
$image=mysqli_fetch_array($query);
?>
 
<html>
<head>
<title>Image fetching from Database</title>
</head>
<body>
 
//If image path is saved in database without folder name.
<img src="<?php echo 'images/'.$path['image'];?>" />
 
//If image path is already saved in database with folder name.
<img src="<?php echo $path['image'];?>" />
 
</body>
</html>