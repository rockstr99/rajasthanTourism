<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>update database</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Update Data</h2>
  </div>
	
  <form method="post" action="update.php">
  	
  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" value="<?php echo $_SESSION['username']; ?> " disabled >
  	</div>
    <div class="input-group">
  	  <label>Name</label>
  	  <input type="text" name="name" value="">
  	</div>
 <!-- <div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" value="">
  	</div> --->
  	<div class="input-group">
  	  <label>Age</label>
  	  <input type="text" name="age" value="" >
  	</div>
  	<div class="input-group">
  	  <label>Mobile_num</label>
  	  <input type="text" name="mob" value="">
  	</div>
    <div class="input-group">
  	  <label>instagram_url</label>
  	  <input type="text" name="insta" value="">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="upd_user">Update</button>
  	</div>
  	<strong><?php echo $username1; ?></strong>

  </form>
  
  
</body>
</html>