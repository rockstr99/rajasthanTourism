
<!DOCTYPE html>
<html>
<style type="text/css">
table{
	border-collapse:collapse;
	width:100%;
	color= "blue";
	font-family:"Courier New", Courier, monospace;
	font-size: 25px;
	text-align: left;
}
th{
	background-color:blue;
	color:white;
}
</style>
<body>
<table>
<tr>
<th>SNO.</th>
<th>NAME</th>
<th>AGE</th>
<th>MOB NO.</th>
<th>LANGUAGE</th>
<th>LOCATION</th>
<th>FILE</th>
</tr>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, name, age, mob, lang, location FROM users";
$sql1 = "SELECT image FROM images";

$result = $conn->query($sql);
$result1 = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>". $row["id"]."</td><td>". $row["name"]."</td><td>". $row["age"]."</td><td>". $row["mob"]."</td><td>". $row["lang"]."</td><td>". $row["location"];
    }
	echo "</table>";
	
	} else {
    echo "0 results";
}




$conn->close();
?>

</body>
</html>
